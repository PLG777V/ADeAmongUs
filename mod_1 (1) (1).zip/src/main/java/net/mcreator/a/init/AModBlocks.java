
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.a.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.a.block.RubyOreBlock;
import net.mcreator.a.block.RubyBlockBlock;
import net.mcreator.a.block.NederiteOreBlock;
import net.mcreator.a.block.NederiteBlockBlock;
import net.mcreator.a.AMod;

public class AModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, AMod.MODID);
	public static final RegistryObject<Block> NEDERITE_ORE = REGISTRY.register("nederite_ore", () -> new NederiteOreBlock());
	public static final RegistryObject<Block> NEDERITE_BLOCK = REGISTRY.register("nederite_block", () -> new NederiteBlockBlock());
	public static final RegistryObject<Block> RUBY_ORE = REGISTRY.register("ruby_ore", () -> new RubyOreBlock());
	public static final RegistryObject<Block> RUBY_BLOCK = REGISTRY.register("ruby_block", () -> new RubyBlockBlock());
}
