
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.a.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.BlockItem;

import net.mcreator.a.item.RubyItem;
import net.mcreator.a.item.NederiteSwordItem;
import net.mcreator.a.item.NederiteShovelItem;
import net.mcreator.a.item.NederitePickaxeItem;
import net.mcreator.a.item.NederiteIngotItem;
import net.mcreator.a.item.NederiteHoeItem;
import net.mcreator.a.item.NederiteAxeItem;
import net.mcreator.a.item.NederiteArmorItem;
import net.mcreator.a.AMod;

public class AModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, AMod.MODID);
	public static final RegistryObject<Item> NEDERITE_INGOT = REGISTRY.register("nederite_ingot", () -> new NederiteIngotItem());
	public static final RegistryObject<Item> NEDERITE_ORE = block(AModBlocks.NEDERITE_ORE, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> NEDERITE_BLOCK = block(AModBlocks.NEDERITE_BLOCK, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> NEDERITE_PICKAXE = REGISTRY.register("nederite_pickaxe", () -> new NederitePickaxeItem());
	public static final RegistryObject<Item> NEDERITE_AXE = REGISTRY.register("nederite_axe", () -> new NederiteAxeItem());
	public static final RegistryObject<Item> NEDERITE_SWORD = REGISTRY.register("nederite_sword", () -> new NederiteSwordItem());
	public static final RegistryObject<Item> NEDERITE_SHOVEL = REGISTRY.register("nederite_shovel", () -> new NederiteShovelItem());
	public static final RegistryObject<Item> NEDERITE_HOE = REGISTRY.register("nederite_hoe", () -> new NederiteHoeItem());
	public static final RegistryObject<Item> NEDERITE_ARMOR_HELMET = REGISTRY.register("nederite_armor_helmet", () -> new NederiteArmorItem.Helmet());
	public static final RegistryObject<Item> NEDERITE_ARMOR_CHESTPLATE = REGISTRY.register("nederite_armor_chestplate",
			() -> new NederiteArmorItem.Chestplate());
	public static final RegistryObject<Item> NEDERITE_ARMOR_LEGGINGS = REGISTRY.register("nederite_armor_leggings",
			() -> new NederiteArmorItem.Leggings());
	public static final RegistryObject<Item> NEDERITE_ARMOR_BOOTS = REGISTRY.register("nederite_armor_boots", () -> new NederiteArmorItem.Boots());
	public static final RegistryObject<Item> RUBY = REGISTRY.register("ruby", () -> new RubyItem());
	public static final RegistryObject<Item> RUBY_ORE = block(AModBlocks.RUBY_ORE, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> RUBY_BLOCK = block(AModBlocks.RUBY_BLOCK, CreativeModeTab.TAB_BUILDING_BLOCKS);

	private static RegistryObject<Item> block(RegistryObject<Block> block, CreativeModeTab tab) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties().tab(tab)));
	}
}
